﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h> 

struct stack {
	char surname[20];
	char name[20];
	char facult[20];
	char card[20];
	struct stack *next;
};

struct stack *create(struct stack *, int); // присоединение элемента к голове, возврат адреса головы
void list(struct stack *); // просмотр структуры

int main() {
	int i, n;
	struct stack *head; // адрес, указывающий на голову структуры
	head = NULL;
	printf("Vvedite kol-vo studentov:\n");
	scanf("%d", &n);
	for (i = 0; i <= n-1; i++) {
		head = create(head, i);
	}
	printf("\n");
	list(head);
	free(head);
	system("pause");
}

struct stack *create(struct stack *head, int x) {
	struct stack *element; // указатель на новую структуру
	element = (struct stack *)malloc(sizeof(struct stack)); // выделяем память
	element->next = head;
	printf("VVEDITE FAMILIYU:\n");
	scanf("%s", &element->surname);
	printf("VVEDITE IMYA:\n");
	scanf("%s", &element->name);
	printf("VVEDITE FACULTET:\n");
	scanf("%s", &element->facult);
	printf("VVEDITE NOMER ZACHETKI:\n");
	scanf("%s", &element->card);
	return element;
}

void list(struct stack *p){
	bool cSURNAME = false;
	bool cNAME = false;
	bool cFACULT = false;
	bool cCARD = false;
	char symbol[2];
	char check[20];
	printf("1 | 2 | 3 | 4 |\n");
	scanf("%s", &symbol);
	printf("VVEDITE ZNACHENIE:\n");
	scanf("%s", &check);
	if (strcmp(symbol, "1") == 0)
	{
		cSURNAME = true;
	}
	if (strcmp(symbol, "2") == 0)
	{
		cNAME = true;
	}
	if (strcmp(symbol, "3") == 0)
	{
		cFACULT = true;
	}
	if (strcmp(symbol, "4") == 0)
	{
		cCARD = true;
	}

	printf("FAMILIYA\tIMYA\tFACULTET\t\tZACHETKA\n\n");
	while (p != NULL) { // пока не конец 
		if ((cSURNAME == true && strcmp(check, p->surname) == 0) ||
			(cNAME == true && strcmp(check, p->name) == 0) ||
			(cFACULT == true && strcmp(check, p->facult) == 0) ||
			(cCARD == true && strcmp(check, p->card) == 0)){
			printf("%s\t\t%s\t%s\t\t\t%s\n\n", p->surname, p->name, p->facult, p->card);
			printf("\n");
		}
		p = p->next; // продвижение по списку
	}
}